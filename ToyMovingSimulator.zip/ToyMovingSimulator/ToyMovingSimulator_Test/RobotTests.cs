﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ToyMovingSimulator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToyMovingSimulator_Test
{
    [TestClass()]
    public class RobotTests
    {
        [TestMethod()]
        public void CheckMoveTest_initial()
        {
            Dimension standardTable = new Dimension(5, 5);
            Robot robot = new Robot(standardTable, new Position(), Direction.East);

            Assert.IsTrue(robot.CheckMove());
        }

        [TestMethod()]
        public void CheckMoveTest_boundary()
        {
            Dimension standardTable = new Dimension(5, 5);
            Robot robot = new Robot(standardTable, new Position(5, 5), Direction.East);

            Assert.IsFalse(robot.CheckMove());
        }

        [TestMethod()]
        public void CheckMoveTest_Random_InRange()
        {
            Random random = new Random();
            int rows = random.Next(1, 10);
            int cols = random.Next(1, 10);

            int x = random.Next(0, cols - 1);
            int y = random.Next(0, rows - 1);

            Robot robot = new Robot(new Dimension(rows, cols), new Position(x, y), Direction.East);

            Assert.IsTrue(robot.CheckMove());
        }

        [TestMethod()]
        public void CheckMoveTest_Random_InRange_Multiple()
        {
            var isChecked = true;
            for (int i = 0; i < 10; i++)
            {
                Random random = new Random();
                int rows = random.Next(1, 10);
                int cols = random.Next(1, 10);

                int x = random.Next(0, cols - 1);
                int y = random.Next(0, rows - 1);

                Robot robot = new Robot(new Dimension(rows, cols), new Position(x, y), Direction.East);

                isChecked = isChecked && robot.CheckMove();
            }
            Assert.IsTrue(isChecked);
        }

        [TestMethod()]
        public void CheckMoveTest_Random_OutRange_Multiple()
        {
            var isChecked = false;
            for (int i = 0; i < 10; i++)
            {
                Random random = new Random();
                int rows = random.Next(1, 10);
                int cols = random.Next(1, 10);

                int x = random.Next(cols + 1, 100);
                int y = random.Next(rows + 1, 100);

                Robot robot = new Robot(new Dimension(rows, cols), new Position(x, y), Direction.East);

                isChecked = isChecked || robot.CheckMove();
            }
            Assert.IsFalse(isChecked);
        }

        [TestMethod()]
        public void CheckMoveTest_Random_OutRange()
        {
            Random random = new Random();
            int rows = random.Next(1, 10);
            int cols = random.Next(1, 10);

            int x = random.Next(cols + 1, 100);
            int y = random.Next(rows + 1, 100);

            Robot robot = new Robot(new Dimension(rows, cols), new Position(x, y), Direction.East);

            Assert.IsFalse(robot.CheckMove());
        }
    }
}